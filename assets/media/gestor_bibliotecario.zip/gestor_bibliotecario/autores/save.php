<?php
    require_once "../config/connection.php";

    if ($_SERVER["REQUEST_METHOD"] !== "POST") {
        header("Location: index.php");
        exit;
    }

    $nombre           = trim($_POST["nombre"] ?? "");
    $apellido         = trim($_POST["apellido"] ?? "");
    $nacionalidad     = trim($_POST["nacionalidad"] ?? "");
    $fecha_nacimiento = trim($_POST["fecha_nacimiento"] ?? "") ?: null;

    if ($nombre === "" || $apellido === "") {
        header("Location: create.php?error=" . urlencode("El nombre y apellido son obligatorios"));
        exit;
    }

    // Aquí va el código para crear el autor usando una consulta preparada
?>
